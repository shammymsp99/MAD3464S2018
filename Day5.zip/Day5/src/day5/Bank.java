/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day5;

/**
 *
 * @author macstudent
 */
public class Bank {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      String bankname;
      int bankid;
      
      //default constructors
      Bank(){
        this.bankname="Unkown";
        this.bankid=0;
    }
     
      //parameterized constructor
      Bank(String bankname, int bankid,int accno, String custname,double balamnt){
        this.bankname=bankname;
        this.bankid=bankid;
    }
      
      /*@Override
    public String toString(){
        String data="Bank Name : " + bankname + "\n" + "Bank Id : " + bankid + "\n";
        return data;
    }*/
      
      BankAccount bac1 = new BankAccount();
      System.out.println(bac1.toString());
      
      BankAccount bac2 = new BankAccount("SCOTIA BANK",420,123456,"Chamaan",0.0);
      System.out.println(bac2.toString());
    
     /*BankAccount bac3 = new BankAccount();
     System.out.println(bac3.setData());
       */
    }   
    private String bankname;
    private int bankid;

    private static Bank() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static Bank() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static Bank() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
