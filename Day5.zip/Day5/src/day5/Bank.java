/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day5;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Bank {

   
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner in = new Scanner(System.in);
      
      
//      Bank();
      
      BankDetails bd1 = new BankDetails("NSB101","Bank Of Nova Scotia");
      
      //BankAccount bac1 = new BankAccount();
      //System.out.println(bac1.toString());
      
      BankAccount bac1 = new BankAccount("NSB101","Bank Of Nova Scotia","A101","Chamaan",2000);
      System.out.println(bac1.toString());
      
     
      OverDraftAccount oda1 = new OverDraftAccount("RBC101", "Royal Bank", "B101", "Chamaan", 5000);
        System.out.println(oda1.toString());
        oda1.withdrawOverdraft();
      
}
}

