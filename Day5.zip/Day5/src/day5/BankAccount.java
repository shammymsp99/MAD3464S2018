/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day5;

import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class BankAccount extends Bank{
    
    int accno;
    String custname;
    double balamnt;
    Scanner in = new Scanner(System.in);
    
    //default constructor
    BankAccount(){
        super();
        this.accno=1;
        this.custname="Unknown";
        this.balamnt=0;
    }
    
    //parmeterized constructor 
    BankAccount(String bankname, int bankid, int accno, String custname,double balamnt ){
        super(bankname, bankid);
        this.accno=accno;
        this.custname=custname;
        this.balamnt=balamnt;

    }
    
    void setAccno(){
        System.out.println("Enter the Account No: ");
        accno = in.nextInt();
    }
    int getAccno(){
        return accno;
    }
    void setcustName(){
       System.out.println("Enter the Customer Name No: ");
       custname= in.nextLine();
    }
    String getcustName(){
        return custname;
    }
    void setbalAmnt(){
        System.out.println("Enter the Balance Amount: ");
        balamnt = in.nextDouble();
    }
    double getbalAmnt(){
        return balamnt;
    }
    
    @Override
    public String toString(){
        String personalDetails = super.toString();
        String data = "Account Number : " + accno + "\n" +
                "Customer-Name  : " + custname + "\n" +
                "Balance Amount No : " + balamnt + "\n" ;               
        
        return personalDetails+data;
    }
    
    void setData(){
        setAccno();
        setcustName();
        setbalAmnt();
    }
}
