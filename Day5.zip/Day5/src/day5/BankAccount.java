/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day5;

import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class BankAccount extends BankDetails{
    
    String accountNo;
    String ownerName;
    double balance;
    Scanner in = new Scanner(System.in);
    
    //default constructor
    BankAccount(){
        super();
        this.accountNo=null;
        this.ownerName=null;
        this.balance=0;
    }
    
    //parmeterized constructor 
    BankAccount(String BankId, String BankName, String accno, String custname,double balamnt){
        super(BankId,BankName);
        this.accountNo=accno;
        this.ownerName=custname;
        this.balance=balamnt;

    }
    @Override
    public String toString(){
        return("Account Number : " + accountNo + "\n" +
                "Customer-Name  : " + ownerName + "\n" +
                "Balance Amount No : " + balance);                     
    }
    
    void setAccno(){
        System.out.println("Enter the Account No: ");
        accountNo = in.nextLine();
    }
    String getAccno(){
        return accountNo;
    }
    void setcustName(){
       System.out.println("Enter the Customer Name No: ");
       ownerName= in.nextLine();
    }
    String getcustName(){
        return ownerName;
    }
    void setbalAmnt(){
        System.out.println("Enter the Balance Amount: ");
        balance = in.nextDouble();
    }
    double getbalAmnt(){
        return balance;
    }
}
