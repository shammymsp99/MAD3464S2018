/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;
import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class Person {
    String name;
    String address;
    String phoneNo;
    int age;
    char gender;
    Scanner in = new Scanner(System.in);
    
    public Person(){
            this.name="sdasd";
        this.address="dfdsfsdf";
        this.phoneNo="911";
        this.gender='m';
        this.age=16;
    }
    //parameterized constructor
    Person(String name, String address, String phoneNo, char gender, int age){
        this.name=name;
        this.address=address;
        this.phoneNo=phoneNo;
        this.gender=gender;
        this.age=age;
    }
    
    //copy constructor
    Person(Person anotherPerson){
        this.name=anotherPerson.name;
        this.address=anotherPerson.address;
        this.phoneNo=anotherPerson.phoneNo;
        this.gender=anotherPerson.gender;
        this.age=anotherPerson.age;
    }
    
    void setName(){
        System.out.println("enter a name");
        name = in.nextLine();
    }
    String getName(){
        return name;
    }
    void setAddress(){
        System.out.println("Enter address : ");
        address = in.nextLine();
    }
    
    String getAddress(){
        return address;
    }
    
    void setGender(){
        System.out.println("Enter gender : ");
        gender = (char)in.nextInt();
    }
    
    char getGender(){
        return gender;
    }
    
    void setAge(){
        System.out.println("Enter age : ");    
        age = in.nextInt();
       
    }
    
    int getAge(){
        return age;
    }
    
    void setPhoneNo(){
        System.out.println("Enter phone no : ");
        phoneNo = in.nextLine();
    }
    
    String getPhoneNo(){
        return phoneNo;
    }
    @Override
    public String toString(){
        String data="name : " + name + "\n" + "Address ; " + address + "\n" + "phone No: " + phoneNo + "\n" + "Gender: " + gender + "\n" + "age : " + age + "\n";
        
        return data;
    }
    void setData(){
        setName();
        setAddress();
        setPhoneNo();
        setGender();
        setAge();
    }
}
