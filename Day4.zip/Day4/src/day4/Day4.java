/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

/**
 *
 * @author macstudent
 */
public class Day4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*Person ishav = new Person();
        System.out.println(ishav.toString());
        
        Person alay = new Person("alay","USA","123456",'M',22);
        System.out.println(alay.toString());
        */
        /*
        Employee emp1= new Employee();
        emp1.name="Kuamari";
        emp1.address="IND";
        emp1.phoneNo="911";
        emp1.age=21;
        emp1.gender='F';
        emp1.empId="F101";
        emp1.dept=20;
        emp1.joiDate="01 June 2018";
        System.out.println(emp1.toString());
        */
        Employee emp2 = new Employee("Satyam","Bihar","911",24,'T',"P123",30,"20 may 2050");
        System.out.println(emp2.toString());
    }
    
}
