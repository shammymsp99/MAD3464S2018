/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3;
import java.util.Scanner;
/**
 *
 * @author macstudent
 */
public class Day3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person shashank=new Person();
        shashank.name="Shashank";
        shashank.address="Toronto";
        shashank.gender= 'M';
        shashank.age=22;
        shashank.phoneno="911";
        System.out.println("Name : " +shashank.name);
        System.out.println("Address : " +shashank.address);
        System.out.println("Gender : " +shashank.gender);
        System.out.println("Age : " +shashank.age);
        System.out.println("PhoneNo : " +shashank.phoneno);
    /*
    Person santhu = new Person();
    santhu.setName();
    System.out.println("Name : " + santhu.getName());
    santhu.setAddress();
    System.out.println("Address : " + santhu.getName());
    santhu.setPhoneNo();
    System.out.println("Enter a Phone No" + santhu.getPhoneNo());
    santhu.setGender();
    System.out.println("Enter a Gender" + santhu.getGender());
    santhu.setAge();
    System.out.println("Enter a Age" + santhu.getAge());
    
    System.out.println(santhu.toString());
    } */
    Person saloni= new Person();
    saloni.setData();
    System.out.println(saloni.toString());
    
}
}
