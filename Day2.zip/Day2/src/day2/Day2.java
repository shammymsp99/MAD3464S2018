/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

/**
 *
 * @author macstudent
 */
public class Day2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Arithmetic operation1=new Arithmetic();
        System.out.println("number :"+operation1.number1);
        operation1.addition();
        operation1.addition(20,34);
        float result=operation1.addition(12.34f,34.23f);
        system.out.println("result :" +result);
        operation1.addition(10,20);
        
        /*for(int row=5; row>0; row--){
            for(int space=5; space>row; space--){
                System.out.print(" ");
            }
            for(int col=0; col<row; col++){
                System.out.print("$ ");
             }
            System.out.println("");
            }*/
      
        }
        }
    }
    
 
